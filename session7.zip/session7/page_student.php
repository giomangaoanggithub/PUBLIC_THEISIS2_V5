<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Essay Speed Checker</title>
    <link rel="stylesheet" href="styles/style-page_student.css">
    <script src="https://code.jquery.com/jquery-3.6.3.js"
        integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <div class="row">
        <div class="col-10" style="padding-left: 2vw;">
            <div class="list-of-tasks">
                <table style="width: 100%">
                    <thead>
                        <tr>
                            <th style="width: 50%;">QUESTIONS</th>
                            <th>ROOM</th>
                            <th>TEACHER</th>
                            <th style="width: 10%">ACTION</th>
                        </tr>
                    </thead>
                    <tbody id="tbody_tasks">
                        <tr>
                            <td>
                                Please Search a room...
                            </td>
                            <td>
                                so you can participate
                            </td>
                            <td>
                                and your teacher will invite you...
                            </td>
                            <td>
                                <button disabled>ANSWER</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <h3 id="question_placement"></h3>
            <textarea name="" id="textarea_input" cols="20" rows="5" style="width: 100%; resize: none;"
                placeholder="Write your answer here...&#10;&#10;Please write your sentence in English and with care. The checking process does not consider grammar, number of sentences, spellings and other rules of writing. It only checks whether you are able to answer the question accordingly or not..."></textarea>
            <div class="row">
                <div class="col-6"><button id="cancel_task">CANCEL</button></div>
                <div class="col-6"><button id="submit_task">SUBMIT</button></div>
            </div>
            <div class="list-of-grades">
                <table style="width: 100%">
                    <thead>
                        <tr>
                            <th style="width: 30%;">QUESTIONS</th>
                            <th style="width: 50%;">ANSWERS</th>
                            <th style="width: 5%;">GRADES</th>
                            <th style="width: 15%">ACTION</th>
                        </tr>
                    </thead>
                    <tbody id="tbody_grades">
                        <tr>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>
                                <!-- <button>RE-EVALUATE</button> -->
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="button-interactives col-2">
            <img src="images/profile.png" alt="" id="user_face" class="img-fluid">
            <br><br>
            <input type="text" placeholder="Classroom Name" style="width: 100%" id="search_room">
            <br>
            <br>
            <input type="password" placeholder="password" style="width: 100%" id="search_room_password">
            <button id="search_room_enter">ENTER</button>
            <button id="search_room_btn">SEARCH CLASSROOM</button>
            <button id="account-settings-btn">ACCOUNT SETTINGS</button>
            <button id="logout-btn">LOGOUT</button>
            <table style="margin-top: 2vh; width: 100%" id="room_stats">
                <thead>
                    <tr>
                        <th>Room</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody id="stud_wait">
                    <tr>
                        <td>yada room</td>
                        <td>on queue</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>
<script src="js/script_page_student.js"></script>

</html>