<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$stud = $_POST["stud_id"];
$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM ((student_answers INNER JOIN teacher_student_connection ON student_answers.owner_student = teacher_student_connection.student_email) INNER JOIN user_accounts ON student_answers.owner_student = user_accounts.email) INNER JOIN created_questions ON student_answers.question_id = created_questions.question_id WHERE teacher_email = '$email' AND owner_teacher = '$email' AND t_s_conn_id = '$stud';");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);

    echo json_encode($result);

  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;

?>