$("#return-btn").click(function () {
  window.location.href = "page_teacher.php";
});

function accept_or_decline(input) {
  if (input[0] == "d") {
    $.post(
      "zerver_page_teacher_view_students_a_or_d.php",
      {
        conn_id: input,
        outcome: -1,
      },
      function () {
        load_data();
      }
    );
  } else if (input[0] == "a") {
    $.post(
      "zerver_page_teacher_view_students_a_or_d.php",
      {
        conn_id: input,
        outcome: 1,
      },
      function () {
        load_data();
      }
    );
  }
}

function viewone_stud(input) {
  input = input.replace("viewstudent_", "");
  // alert(input);
  $.post(
    "zerver_page_teacher_view_students_inner_view.php",
    { stud_id: input },
    function (data) {
      data = JSON.parse(data);
      document.getElementById("name_span").innerHTML =
        "Name: " + data[0]["username"];
      document.getElementById("email_span").innerHTML =
        "Email: " + data[0]["owner_student"];
      document.getElementById("contact_span").innerHTML =
        "Contact Number: " + data[0]["contact_number"];
      document.getElementById("view_face").src = data[0]["profile_pic_address"];
      document.getElementById("view_face").style.borderRadius = "100px";
      output = "";
      for (x = 0; x < data.length; x++) {
        output +=
          "<tr><td>" +
          data[x]["question"] +
          "</td><td>" +
          data[x]["answer"] +
          "</td><td>" +
          (parseFloat(data[x]["grades"]) / 100) * parseFloat(data[x]["HPS"]) +
          "</td><td>" +
          data[x]["HPS"] +
          "</td></tr>";
      }
      $("#main_view").empty();
      $("#main_view").append(output);
    }
  );
}

function load_data() {
  $("#tbody-student-applicants").empty();
  $.get("zerver_page_teacher_view_students_fetch.php", function (data) {
    data = JSON.parse(data);
    table_contents = "";
    for (x = 0; x < data.length; x++) {
      if (data[x]["t_s_connection"] == "0") {
        table_contents +=
          '<tr><td id="studentapp_' +
          data[x]["t_s_conn_id"] +
          '"><img src="' +
          data[x]["profile_pic_address"] +
          '" class="img-fluid"></td><td>' +
          data[x]["username"] +
          "</td><td><button id='accept_" +
          data[x]["t_s_conn_id"] +
          "' onclick='accept_or_decline(this.id)'>✔</button><button id='decline_" +
          data[x]["t_s_conn_id"] +
          "' onclick='accept_or_decline(this.id)'>✖</button></td></tr>";
      }
    }
    $("#tbody-student-applicants").append(table_contents);
  });

  $("#tbody-classroom").empty();
  $.get("zerver_page_teacher_view_students_fetch.php", function (data) {
    data = JSON.parse(data);
    table_contents = "";
    for (x = 0; x < data.length; x++) {
      if (data[x]["t_s_connection"] == "1") {
        table_contents +=
          '<tr><td id="student_' +
          data[x]["t_s_conn_id"] +
          '"><img src="' +
          data[x]["profile_pic_address"] +
          '" class="img-fluid"></td><td>' +
          data[x]["username"] +
          "</td><td>" +
          data[x]["email"] +
          "</td><td><button id='viewstudent_" +
          data[x]["t_s_conn_id"] +
          "' onclick='viewone_stud(this.id)'>VIEW</button></td></tr>";
      }
    }
    $("#tbody-classroom").append(table_contents);
  });
}

$(window).on("load", load_data());
