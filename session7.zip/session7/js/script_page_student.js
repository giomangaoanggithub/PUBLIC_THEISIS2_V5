$("#logout-btn").click(function () {
  window.location.href = "index.php";
});
$("#account-settings-btn").click(function () {
  window.location.href = "page_account_settings.php";
});
$("#search_room_btn").click(function () {
  if (document.getElementById("search_room").style.visibility == "visible") {
    document.getElementById("search_room").style.visibility = "hidden";
    document.getElementById("search_room_password").style.visibility = "hidden";
    document.getElementById("search_room_btn").innerHTML = "SEARCH ROOM";
    document.getElementById("search_room_enter").style.visibility = "hidden";
  } else {
    document.getElementById("search_room").style.visibility = "visible";
    document.getElementById("search_room_password").style.visibility =
      "visible";
    document.getElementById("search_room_btn").innerHTML = "CANCEL SEARCH ROOM";
    document.getElementById("search_room_enter").style.visibility = "visible";
  }
});
$("#cancel_task").click(function () {
  document.getElementById("textarea_input").style.visibility = "hidden";
  document.getElementById("cancel_task").style.visibility = "hidden";
  document.getElementById("submit_task").style.visibility = "hidden";
  document.getElementById("question_placement").style.visibility = "hidden";
});
$("#submit_task").click(function () {
  if (document.getElementById("textarea_input").value.split(" ").length < 11) {
    alert("Please input more than 10 words or more...");
    return;
  }
  document.getElementById("textarea_input").style.visibility = "hidden";
  document.getElementById("cancel_task").style.visibility = "hidden";
  document.getElementById("submit_task").style.visibility = "hidden";
  document.getElementById("question_placement").style.visibility = "hidden";
  $.post(
    "zerver_page_student_send_essay.php",
    {
      essay_answer: document.getElementById("textarea_input").value,
      question_id: document.getElementById("textarea_input").className,
    },
    function () {
      alert("ESSAY ANSWER SUBMITTED!");
    }
  );

  page_start();
});

$("#search_room_enter").click(function () {
  $.post(
    "zerver_page_student_search_room_exist.php",
    {
      room_name: document.getElementById("search_room").value,
      room_code: document.getElementById("search_room_password").value,
    },
    function (data) {
      data = JSON.parse(data);
      if (data.length > 0) {
        teacher_email = data[0]["owner_email"];
        $.post(
          "zerver_page_student_connect_teacher.php",
          {
            room_name: document.getElementById("search_room").value,
            email_teacher: teacher_email,
          },
          function (data) {
            alert(data);
          }
        );
      }
    }
  );
});

function answer_task(input) {
  input = input.replace("answer_", "");
  document.getElementById("textarea_input").style.visibility = "visible";
  document.getElementById("cancel_task").style.visibility = "visible";
  document.getElementById("submit_task").style.visibility = "visible";
  document.getElementById("question_placement").style.visibility = "visible";
  document.getElementById("question_placement").innerHTML =
    document.getElementById("question_" + input).innerHTML;
  document.getElementById("textarea_input").className = input;
}

function page_start() {
  $.get("zerver_teacher_check_acc.php", function (data) {
    if (data == "") {
      window.location.href = "index.php";
    } else {
      document.getElementById("textarea_input").style.visibility = "hidden";
      document.getElementById("cancel_task").style.visibility = "hidden";
      document.getElementById("submit_task").style.visibility = "hidden";
      document.getElementById("question_placement").style.visibility = "hidden";
      $.get("zerver_page_student_check_room.php", function (data) {
        // alert(data);
        data = JSON.parse(data);
        if (data.length > 0) {
          //   alert("room exists");
          document.getElementById("search_room").style.visibility = "hidden";
          document.getElementById("search_room_password").style.visibility =
            "hidden";
          document.getElementById("search_room_enter").style.visibility =
            "hidden";
          $.get("zerver_page_student_fetch_if_answered.php", function (data) {
            // alert(data);
            data = JSON.parse(data);
            alr_ans_arr = [];
            for (x = 0; x < data.length; x++) {
              alr_ans_arr.push(data[x]["question_id"]);
            }
            $.get("zerver_page_student_fetch_tasks.php", function (data) {
              // alert(data);
              data = JSON.parse(data);
              output = "";
              for (x = 0; x < data.length; x++) {
                if (alr_ans_arr.includes(data[x]["question_id"])) {
                  output +=
                    "<tr><td style='background-color: lightgray; color: grey;' id='question_" +
                    data[x]["question_id"] +
                    "'>" +
                    data[x]["question"] +
                    "</td><td style='background-color: lightgray; color: grey;'>" +
                    data[x]["room_name"] +
                    "</td><td style='background-color: lightgray; color: grey;'>" +
                    data[x]["username"] +
                    '</td><td style="background-color: lightgray; color: grey;"><button class="answer_task_btns_disabled" id="answer_' +
                    data[x]["question_id"] +
                    '" onclick="answer_task(this.id)" disabled>ANSWER</button></td><tr>';
                } else {
                  output +=
                    "<tr><td id='question_" +
                    data[x]["question_id"] +
                    "'>" +
                    data[x]["question"] +
                    "</td><td>" +
                    data[x]["room_name"] +
                    "</td><td>" +
                    data[x]["username"] +
                    '</td><td><button class="answer_task_btns" id="answer_' +
                    data[x]["question_id"] +
                    '" onclick="answer_task(this.id)">ANSWER</button></td><tr>';
                }
              }
              $("#tbody_tasks").empty();
              $("#tbody_tasks").append(output);

              $.get(
                "zerver_page_student_fetch_user_image.php",
                function (data) {
                  data = JSON.parse(data);
                  document.getElementById("user_face").src =
                    data[0]["profile_pic_address"];
                  document.getElementById("user_face").style.borderRadius =
                    "40px";
                }
              );
            });
          });
        } else {
          alert("Please Search for a room before you begin...");
        }
      });
    }
  });
}

function stud_queue() {
  $.get("zerver_page_student_stat_queue.php", function (data) {
    // alert(data);
    data = JSON.parse(data);
    output = "";
    for (x = 0; x < data.length; x++) {
      output += "<tr><td>" + data[x]["room_name"] + "</td><td";
      if (data[x]["t_s_connection"] == "1") {
        output += " style='color: green;'>ACCEPTED</td></tr>";
      } else if (data[x]["t_s_connection"] == "0") {
        output += " style='color: orange;'>ON QUEUE</td></tr>";
      } else {
        output += " style='color: red;'>DECLINED</td></tr>";
      }
    }
    $("#stud_wait").empty();
    $("#stud_wait").append(output);
  });
}

function req_re_eval(input) {
  input = input.replace("re_eval_btn_", "");
  $.post(
    "zerver_page_student_req_re_eval.php",
    { req: input },
    function (data) {
      alert(data);
    }
  );
}

function stud_grades() {
  $.get("zerver_page_student_fetch_grades.php", function (data) {
    // alert(data);
    data = JSON.parse(data);
    html_output = "";
    for (x = 0; x < data.length; x++) {
      html_output +=
        "<tr><td>" +
        data[x]["question"] +
        "</td><td>" +
        data[x]["answer"] +
        "</td><td style='text-align: center'>" +
        data[x]["grades"] +
        "</td><td  style='text-align: center'><button id='re_eval_btn_";

      if (data[x]["re_eval"] == "0") {
        html_output +=
          data[x]["answer_id"] +
          "' onclick='req_re_eval(this.id)'>RE-EVALUATION</button></td></tr>";
      } else {
        html_output +=
          data[x]["answer_id"] +
          "' onclick='req_re_eval(this.id)' disabled>QUEUEING...</button></td></tr>";
      }
    }
    $("#tbody_grades").empty();
    $("#tbody_grades").append(html_output);
  });
}
page_start();
stud_queue();
stud_grades();
